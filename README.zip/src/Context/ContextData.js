import React, { createContext } from "react";

export const UserContext = createContext();
const ContextData = (props) => {
  return (
    <UserContext.Provider value={{}}>{props.children}</UserContext.Provider>
  );
};

export default ContextData;
