import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const SignupSchema = yup.object().shape({
  Name: yup.string().required(),
  address: yup.string().required(),
  age: yup.number().required().positive().integer(),
  email: yup.string().email().required(),
  pincode: yup.number().required().positive().integer(),
  occupation: yup.string().required(),
  Emergency_Contact: yup.number().required().positive().integer(),
});

const IssueID = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="PAN">PAN</option>
      <option value="AADHAR">AADHAR</option>
    </select>
  </>
));

const GuardianType = React.forwardRef(
  ({ onChange, onBlur, name, label }, ref) => (
    <>
      <label>{label}</label>
      <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
        <option value="Father">Father</option>
        <option value="Mother">Mother</option>
      </select>
    </>
  )
);

const Select = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>
  </>
));

const Country = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="INDIA">India</option>
      <option value="NEPAL">Nepal</option>
      <option value="USA">USA</option>
      <option value="MEXICO">MEXICO</option>
    </select>
  </>
));

const State = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="state1">State1</option>
      <option value="state2">State2</option>
      <option value="state3">State3</option>
      <option value="state4">State4</option>
    </select>
  </>
));

const City = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="city1">City1</option>
      <option value="city2">City2</option>
      <option value="city3">City3</option>
      <option value="city4">City4</option>
    </select>
  </>
));

const Religion = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="Religion1">Religion1</option>
      <option value="Religion2">Religion2</option>
      <option value="Religion3">Religion3</option>
      <option value="Religion4">Religion4</option>
    </select>
  </>
));

const Marital = React.forwardRef(({ onChange, onBlur, name, label }, ref) => (
  <>
    <label>{label}</label>
    <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
      <option value="Single">Single</option>
      <option value="Married">Married</option>
    </select>
  </>
));

const BloodGroup = React.forwardRef(
  ({ onChange, onBlur, name, label }, ref) => (
    <>
      <label>{label}</label>
      <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
        <option value="A+">A RhD positive (A+)</option>
        <option value="A-">A RhD negative (A-)</option>
        <option value="B+">B RhD positive (B+)</option>
        <option value="B-">B RhD positive (B-)</option>
        <option value="O+">O RhD positive (O+)</option>
        <option value="O-">O RhD positive (O-)</option>
        <option value="AB+">AB RhD positive (AB+)</option>
        <option value="AB-">AB RhD positive (AB-)</option>
      </select>
    </>
  )
);

const Nationality = React.forwardRef(
  ({ onChange, onBlur, name, label }, ref) => (
    <>
      <label>{label}</label>
      <select name={name} ref={ref} onChange={onChange} onBlur={onBlur}>
        <option value="INDIA">India</option>
        <option value="NEPAL">Nepal</option>
        <option value="USA">USA</option>
        <option value="MEXICO">MEXICO</option>
      </select>
    </>
  )
);

function Form() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    initialValues: {
      country: "India",
      state: null,
      city: null,
    },
    resolver: yupResolver(SignupSchema),
  });
  const onSubmit = (data) => {
    alert(JSON.stringify(data));
    console.log(data);
  };

  return (
    <form className="form" onSubmit={handleSubmit(onSubmit)}>
      <h3>Personal Details</h3>
      <div className="main">
        <div>
          <label>Name</label>
          <input {...register("Name")} />
          {errors.Name && <p>{errors.Name.message}</p>}
        </div>
        <div>
          <label>Age</label>
          <input type="number" {...register("age", { valueAsNumber: true })} />
          {errors.age && <p>{errors.age.message}</p>}
        </div>
        <div>
          <Select label="Sex" {...register("sex")} />
        </div>
        <div>
          <IssueID label="Govt Issue ID" {...register("gid")} />
          <input type="number" {...register("gid", { valueAsNumber: true })} />
        </div>
      </div>
      <h3>Contact Details</h3>
      <div className="main">
        <div>
          <GuardianType label="Guardian Details" {...register("guardian")} />
          <input {...register("guardian_name")} />
        </div>
        <div>
          <label>Email</label>
          <input type="email" {...register("email")} />
          {errors.email && <p>{errors.email.message}</p>}
        </div>
        <div>
          <label>Emergency Contact</label>
          <input
            type="number"
            {...register("Emergency_Contact", { valueAsNumber: true })}
          />
          {errors.Emergency_Contact && (
            <p>{errors.Emergency_Contact.message}</p>
          )}
        </div>
      </div>

      <h3>Address Details</h3>
      <div className="main">
        <div>
          <label>Address</label>
          <input {...register("address")} />
          {errors.address && <p>{errors.address.message}</p>}
        </div>
        <div>
          <Country label="Country" {...register("country")} />
        </div>
        <div>
          <State label="State" {...register("state")} />
        </div>
        <div>
          <City label="City" {...register("city")} />
        </div>
        <div>
          <label>Pincode</label>
          <input {...register("pincoode")} />
          {errors.pincode && <p>{errors.pincode.message}</p>}
        </div>
      </div>

      <h3>Other Details</h3>
      <div className="main">
        <div>
          <label>Occupation</label>
          <input {...register("occupation")} />
          {errors.occupation && <p>{errors.occupation.message}</p>}
        </div>
        <div>
          <label>Religion</label>
          <Religion {...register("religion")} />
        </div>
        <div>
          <label>Marital</label>
          <Marital {...register("marital")} />
        </div>
        <div>
          <label>BloodGroup</label>
          <BloodGroup {...register("bloodgroup")} />
        </div>
        <div>
          <label>Nationality</label>
          <Nationality {...register("nationality")} />
        </div>
      </div>
      <div className="main-2">
        <input type="submit" />
      </div>
    </form>
  );
}

export default Form;
