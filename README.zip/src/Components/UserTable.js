import React from "react";

const UserTable = () => {
  return <div>UserTable</div>;
};

export default UserTable;
